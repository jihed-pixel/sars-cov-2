
import {  combineReducers} from "redux";
import {  medicalService} from "./medicalService";

export const reducers=combineReducers({
    medicalService
})